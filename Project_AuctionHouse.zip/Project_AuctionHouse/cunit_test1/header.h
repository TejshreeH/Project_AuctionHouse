#ifndef HEADER_H
#define HEADER_H
int sum(int,int);
int diff(int,int);
#endif
